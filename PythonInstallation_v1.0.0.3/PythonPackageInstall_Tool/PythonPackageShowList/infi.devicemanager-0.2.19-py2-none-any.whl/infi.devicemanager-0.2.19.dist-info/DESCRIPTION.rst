Python bindings to Windows Device Managers' API


